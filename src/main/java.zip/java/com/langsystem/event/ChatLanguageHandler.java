package com.langsystem.event;

import com.langsystem.LangSystemMod;
import com.langsystem.Language;
import com.langsystem.data.LanguageData;
import com.langsystem.data.ModAttachments;
import com.langsystem.util.RuneCipher;
import com.langsystem.util.Visibility;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.ServerChatEvent;

@EventBusSubscriber(modid = LangSystemMod.MOD_ID)
public final class ChatLanguageHandler {

    /** Максимальная дистанция, на которой вообще можно разглядеть жесты. */
    private static final double SIGN_VISIBILITY_RANGE = 32.0;

    @SubscribeEvent
    public static void onServerChat(ServerChatEvent event) {
        ServerPlayer sender = event.getPlayer();
        LanguageData senderData = sender.getData(ModAttachments.LANGUAGE_DATA);
        Language spoken = senderData.current();

        String rawMessage = event.getRawText();
        MinecraftServer server = sender.server;

        // Перехватываем стандартную рассылку — сами решаем, что покажет каждый получатель.
        event.setCanceled(true);

        Component senderNameTag = Component.literal("<")
                .append(sender.getDisplayName().copy())
                .append(Component.literal(" [" + spoken.displayName() + "]"))
                .append(Component.literal("> "));

        for (ServerPlayer recipient : server.getPlayerList().getPlayers()) {
            String bodyText;

            if (spoken == Language.SIGN && recipient != sender && !Visibility.canSee(recipient, sender, SIGN_VISIBILITY_RANGE)) {
                // Язык жестов чисто визуальный — если получатель не видит говорящего
                // (закрыт стеной, отвернулся, слишком далеко), понять его невозможно
                // вообще, независимо от уровня владения языком.
                bodyText = "* показывает жестами, но вы не видите говорящего *";
            } else {
                LanguageData recipientData = recipient.getData(ModAttachments.LANGUAGE_DATA);
                int understanding = recipient == sender ? 100 : recipientData.progress(spoken);
                bodyText = RuneCipher.encipher(rawMessage, spoken, understanding);
            }

            MutableComponent line = Component.empty()
                    .append(senderNameTag)
                    .append(Component.literal(bodyText).withStyle(style -> style.withColor(spoken.color())));

            recipient.sendSystemMessage(line);
        }

        // Лог на сервере всегда на языке оригинала (в консоль/файл лога).
        LangSystemMod.LOGGER.info("[Chat/{}] {}: {}", spoken.id(), sender.getGameProfile().getName(), rawMessage);
    }

    private ChatLanguageHandler() {
    }
}
