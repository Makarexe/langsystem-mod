package com.langsystem.network;

import com.langsystem.Language;
import com.langsystem.data.LanguageData;
import com.langsystem.data.ModAttachments;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class NetworkHandler {

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");

        registrar.playToServer(
                SetLanguagePayload.TYPE,
                SetLanguagePayload.STREAM_CODEC,
                NetworkHandler::handleSetLanguage
        );

        registrar.playToClient(
                SyncLanguagePayload.TYPE,
                SyncLanguagePayload.STREAM_CODEC,
                ClientPacketHandler::handleSync
        );
    }

    private static void handleSetLanguage(SetLanguagePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (!(context.player() instanceof ServerPlayer serverPlayer)) {
                return;
            }
            var opt = Language.byId(payload.languageId());
            if (opt.isEmpty()) {
                return;
            }
            LanguageData data = serverPlayer.getData(ModAttachments.LANGUAGE_DATA);
            if (!data.setCurrent(opt.get())) {
                return; // игрок не знает этот язык вообще (прогресс 0) — игнорируем
            }
            serverPlayer.setData(ModAttachments.LANGUAGE_DATA, data);
            serverPlayer.displayClientMessage(
                    net.minecraft.network.chat.Component.literal("Текущий язык: " + opt.get().displayName())
                            .withStyle(style -> style.withColor(opt.get().color())),
                    true
            );
            sendSync(serverPlayer);
        });
    }

    /** Отправить игроку актуальные данные о его языках (вызывать при входе и после give/take). */
    public static void sendSync(ServerPlayer player) {
        LanguageData data = player.getData(ModAttachments.LANGUAGE_DATA);
        List<String> ids = new ArrayList<>();
        List<Integer> percents = new ArrayList<>();
        for (Map.Entry<Language, Integer> entry : data.allProgress().entrySet()) {
            ids.add(entry.getKey().id());
            percents.add(entry.getValue());
        }
        PacketDistributor.sendToPlayer(player, new SyncLanguagePayload(ids, percents, data.current().id()));
    }

    private NetworkHandler() {
    }
}
