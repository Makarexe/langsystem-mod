package com.langsystem.util;

import com.langsystem.Language;

/**
 * Превращает произвольный текст в частично понятную речь в зависимости от уровня
 * прогресса изучения языка (0-100). Преобразование детерминировано — одинаковый текст
 * при одинаковом прогрессе всегда выглядит одинаково, поэтому сообщение не "мерцает"
 * от игрока к игроку без причины, но зато на 0% выглядит полной абракадаброй,
 * а чем выше прогресс — тем больше настоящих букв проступает через шифр.
 */
public final class RuneCipher {

    private RuneCipher() {
    }

    /**
     * @param progressPercent 0..100, доля текста, которая останется читаемой как есть
     */
    public static String encipher(String text, Language language, int progressPercent) {
        int progress = Math.max(0, Math.min(100, progressPercent));
        if (progress >= 100) {
            return text;
        }
        String alphabet = language.glyphAlphabet();
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isWhitespace(c) || !Character.isLetterOrDigit(c)) {
                // пробелы и пунктуацию оставляем как есть, чтобы сохранить ритм фразы
                out.append(c);
                continue;
            }
            int seed = Math.abs((int) c * 31 + i * 17 + language.ordinal() * 7);
            boolean understood = (seed % 100) < progress;
            if (understood) {
                out.append(c);
            } else {
                char glyph = alphabet.charAt(seed % alphabet.length());
                out.append(glyph);
            }
        }
        return out.toString();
    }
}
