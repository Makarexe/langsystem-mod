package com.langsystem.data;

import com.langsystem.LangSystemMod;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModAttachments {

    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, LangSystemMod.MOD_ID);

    public static final DeferredHolder<AttachmentType<?>, AttachmentType<LanguageData>> LANGUAGE_DATA =
            ATTACHMENT_TYPES.register("language_data", () -> AttachmentType.builder(LanguageData::new)
                    .serialize(LanguageData.CODEC)
                    .copyOnDeath()
                    .build());

    private ModAttachments() {
    }
}
